import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Projects from './components/projects';
import AddProject from './components/AddProject';
class App extends Component {
  constructor()
  {
    super()
    this.state={
      projectsfromApp:  [ ]
    }
  }
 
  componentWillMount(){
   alert ("Let the game begin");
   
   this.setState({
    projectsfromApp: 
    [
      {Id: "1001",
      Name:"Vaibhav"
      },
      {
       Id: "1002",
       Name: "Rahul"
      }
    ] 
  });
  console.log(this.state.projectsfromApp);
  }
 
 handleAddProject(newProj) {
  alert("data submitted to app");
  console.log("Data submitted to "+ newProj)
  let projects = this.state.projectsfromApp;
  projects.push(newProj);
  this.setState({ projectsfromApp: projects})
 }
  render() {
    return (
      <div className="App">
       This is my first attempt
       <AddProject onAddProject={this.handleAddProject.bind(this)}/>
       <Projects ProjectFromApp={this.state.projectsfromApp} test="Hello World"/>
      </div>
       );
  }
}


export default App;

