import React, { Component } from 'react';


class ProjectItem extends Component {
  render() {
    return (
    <li className="Projects">
       <strong>{this.props.oneproject.Id}</strong><br/>
        {this.props.oneproject.Name}
        </li>
       
    )
  
  }
}

export default ProjectItem;
