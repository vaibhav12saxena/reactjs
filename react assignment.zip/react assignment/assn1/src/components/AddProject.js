import React, { Component } from 'react';


class AddProject extends Component {
  constructor(){
      super();
      this.state={
          newProject:{}
      }
  }

  handleSubmit(e){
    if(this.refs.title.value==""){
        alert("Please don't waste your time");
      }
      else{
       // alert("Submitted "+ this.refs.title.value);
        //alert("Submitted "+ this.refs.name.value);
          alert("Value submitted")
        this.setState({
            newProject:{
               Id:this.refs.title.value,
              Name:this.refs.name.value,
            }
        },function(){
            console.log("new state: "+ this.state)
            this.props.onAddProject(this.state.newProject);  
        }
          );
  
  }
  e.preventDefault();
 }
  render() {
   /*let categoryOptions=this.props.categories.map(
       onecategory=>{
       return <option key={onecategory} value={onecategory}>{onecategory} </option>
       }
   )

*/

    return (
          <div>
              <h3> Add New Entry</h3> 
              <form onSubmit={this.handleSubmit.bind(this)}>
                  <div>
                      <label>Enter Id:</label><br/>
                      <input type='text' ref='title'/><br/><br/>
                      </div>
                      <div>
                      <label>Enter Name:</label><br/>
                      <input type='text' ref='name'/><br/><br/>
                      </div>          
                      <input type="submit" value="submit data"/>
                      </form>
              
              
              
              </div>

        )}
}

export default AddProject; 