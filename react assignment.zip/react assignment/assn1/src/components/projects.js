import React, { Component } from 'react';
import ProjectItem from './projectitem'

class Projects extends Component {
  render() {
 let projectItems;
   projectItems=this.props.ProjectFromApp.map(
    project =>{
    return(
         <ProjectItem key={project.Id} oneproject= {project}/>
      );
  } 
   );
      
  return (
<div>
{projectItems}

  </div>
    )}
}

export default Projects;
