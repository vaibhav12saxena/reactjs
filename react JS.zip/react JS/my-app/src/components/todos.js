import React, { Component } from 'react';
import PropTypes from 'prop-types'

class Todos extends Component {

  
  render() {
let data=this.props.onData.map(
    oneData=>{
        return <li>{oneData.id}</li>
    }
)

    return (
      <div>
            {data}
    </div>
      
    );
  }
}



export default Todos;
